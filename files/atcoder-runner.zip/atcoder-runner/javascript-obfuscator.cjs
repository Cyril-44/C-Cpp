#!/usr/bin/env node
'use strict';

async function main() {
    const fs = require('node:fs');
    const input = process.argv[2];
    if (!input) throw new Error('Usage: node javascript-obfuscator.cjs INPUT [OPTIONS_JSON]');
    const apiToken = process.env.JAVASCRIPT_OBFUSCATOR_API_KEY;
    if (!apiToken) throw new Error('Set JAVASCRIPT_OBFUSCATOR_API_KEY in config.json obfuscators.javascript.env.');
    let obfuscator;
    try {
        obfuscator = require('javascript-obfuscator');
    } catch (error) {
        throw new Error('javascript-obfuscator is not installed in the project directory; follow README.');
    }
    if (typeof obfuscator.obfuscatePro !== 'function') {
        throw new Error('Installed javascript-obfuscator lacks obfuscatePro; use a version supporting the Pro API.');
    }
    const options = process.argv[3] ? JSON.parse(process.argv[3]) : {
        target: 'node', compact: true, vmObfuscation: true
    };
    const result = await obfuscator.obfuscatePro(fs.readFileSync(input, 'utf8'), options, { apiToken });
    process.stdout.write(result.getObfuscatedCode());
}

main().catch(error => {
    const token = process.env.JAVASCRIPT_OBFUSCATOR_API_KEY;
    const message = String(error.message || error);
    console.error(token ? message.split(token).join('[redacted]') : message);
    process.exitCode = 1;
});
