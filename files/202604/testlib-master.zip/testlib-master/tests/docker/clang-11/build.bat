"C:\Program Files\Docker\Docker"\DockerCli.exe -SwitchLinuxEngine

docker build . -t test-testlib-clang-11

