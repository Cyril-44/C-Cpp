#ifndef OBFUSCATOR
#define OBFUSCATOR

#include "obfs/fsm.hpp"
#include "obfs/random.hpp"
#include "obfs/sequence.hpp"
#include "obfs/string.hpp"

#endif