#include "../obfuscator.hpp"

#include <iostream>

int main() {
    std::cout << MAKE_RAND_VAL(100) << std::endl;
    return 0;
}