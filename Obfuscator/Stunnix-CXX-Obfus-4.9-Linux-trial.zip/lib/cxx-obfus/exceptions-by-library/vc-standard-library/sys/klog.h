#Encrypted file follows
ovmmqus`u
lmphdum
D
tue`TZT`LMPH`I
qusejgg`u
tj{f`u
